//Server Side
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>

#define PORT 8083
#define MAXLINE 1024

//Start Server
int main(){
	int socketfd;//socket pointer
	char buffer[MAXLINE];
	struct sockaddr_in servaddr;//server address
	
	//Create Socket fd, catch error
	if((socketfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0){
		perror("Socket creation failure");
		exit(EXIT_FAILURE);
	}
	
	//set the server address
	memset(&servaddr, 0, sizeof(servaddr));
	
	//Server Info
	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons(PORT);
	servaddr.sin_addr.s_addr = INADDR_ANY;
	
	//declare required variables
	int len,n;
	char op[4]; 
	int x,y; 
	int success, result;
	
	//setup
	printf("Use add, sub, mul, div to specify operation, press control + c to exit\n");
	printf("Example: add 3 7\n");
	printf("Enter Value: \n"); 
	
	//read variables
	scanf("%s %d %d", &op, &x, &y);
	
	//send the values to the server
	sendto(socketfd, &op, sizeof(op), MSG_CONFIRM, (const struct sockaddr *) &servaddr, sizeof(servaddr));
	sendto(socketfd, &x, sizeof(x), MSG_CONFIRM, (const struct sockaddr *) &servaddr, sizeof(servaddr));
	sendto(socketfd, &y, sizeof(y), MSG_CONFIRM, (const struct sockaddr *) &servaddr, sizeof(servaddr));
	printf("Operation Sent.\n");
	
	//Receive success/fail and result from the server
	n = recvfrom(socketfd, &success, sizeof(success),
	 MSG_WAITALL, ( struct sockaddr *) &servaddr, &len);
	n = recvfrom(socketfd, &result, sizeof(result),
	 MSG_WAITALL, ( struct sockaddr *) &servaddr, &len);
	 
	//print results
	if(success == 1)
	{
		printf("Operation successful! Code: %d\n", success);
	}
	else
	{
		printf("Operation unsuccessful. Code: %d\n", success);
	}
	printf("Result from server: %d\n", result);
	
	close(socketfd);
	return 0;
}
