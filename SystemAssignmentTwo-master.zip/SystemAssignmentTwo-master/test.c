#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

int main(){
	system("make duplicate\n");
	
	//Run with no errors
	printf("\nRun with no errors\n");
	system("./duplicate text.txt copy.txt \n");
	
	//Run with main file not having permissions
	printf("\nRun with main file not having permissions\n");
	system("./duplicate closed.txt copy.txt \n");
	
	//Run with target file not having permissions
	printf("\nRun with target file not having permissions\n");
	system("./duplicate text.txt closed.txt \n");
	
	//Run with incorrect argument count
	printf("\nRun with incorrect argument count\n");
	system("./duplicate yeet yeet yeet yeet \n");
	
	exit(0);
}
