//Server Side
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>

#define PORT 8083
#define MAXLINE 1024

//check if divide by 0
int checkValid (char op[3], int x, int y)
{
	if(strcmp(op, "div") == 0)
	{
		if(y == 0)
			return 0;
	}
	return 1;
}

//perform specified operation and return result
int calculate (char op[3], int x, int y)
{
	if(strcmp(op, "add") == 0)
	{
		return x+y;
	}
	if(strcmp(op, "sub") == 0)
	{
		return x-y;
	}
	if(strcmp(op, "mul") == 0)
	{
		return x*y;
	}
	if(strcmp(op, "div") == 0)
	{
		if(y == 0)
			return 0;
		else
			return x/y;
	}
}

//Start Server
int main(){
	//server variables
	int socketfd;
	int success, result;
	struct sockaddr_in servaddr, cliaddr;
	
	//Create Socket fd
	if((socketfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0){
		perror("Socket creation failure");
		exit(EXIT_FAILURE);
	}
	
	//set
	memset(&servaddr, 0, sizeof(servaddr));
	memset(&cliaddr, 0, sizeof(cliaddr));
	
	//Server Info
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = INADDR_ANY;
	servaddr.sin_port = htons(PORT);
	
	//Bind socket and server
	if(bind(socketfd, (const struct sockaddr *)&servaddr, sizeof(servaddr)) < 0)
	{
		perror("bind failure");
		exit(EXIT_FAILURE);
	}
	
	int len,n;
	char op[4]; 
	int x,y; 
	
	//Recieve messages from the client
	n = recvfrom(socketfd, &op, sizeof(op),
	 MSG_WAITALL, ( struct sockaddr *) &cliaddr, &len);
	n = recvfrom(socketfd, &x, sizeof(x),
	 MSG_WAITALL, ( struct sockaddr *) &cliaddr, &len);
	n = recvfrom(socketfd, &y, sizeof(y),
	 MSG_WAITALL, ( struct sockaddr *) &cliaddr, &len);
	
	//print values recieved from the client
	printf("Client: %s\n", op);
	printf("Client: %d\n", x);
	printf("Client: %d\n", y);
	
	//check inputs
	success = checkValid(op,x,y);
	result = calculate(op,x,y);		
	
	//return values to client
	sendto(socketfd, &success, sizeof(success), MSG_CONFIRM, (const struct sockaddr *) &cliaddr, sizeof(cliaddr));
	sendto(socketfd, &result, sizeof(result), MSG_CONFIRM, (const struct sockaddr *) &cliaddr, sizeof(cliaddr));
	printf("Response sent.\n");
	
	//close server socket
	close(socketfd);
	return 0;
}
