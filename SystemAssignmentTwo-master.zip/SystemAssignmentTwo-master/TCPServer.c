#include <stdio.h> 
#include <netdb.h> 
#include <netinet/in.h> 
#include <stdlib.h> 
#include <string.h> 
#include <sys/socket.h> 
#include <sys/types.h> 
#define MAX 80 
#define PORT 8082 
#define SA struct sockaddr

//check if divide by 0
int checkValid (char op[3], int x, int y)
{
	if(strcmp(op, "div") == 0)
	{
		if(y == 0)
			return 0;
	}
	return 1;
}

//perform specified operation and return result
int calculate (char op[3], int x, int y)
{
	if(strcmp(op, "add") == 0)
	{
		return x+y;
	}
	if(strcmp(op, "sub") == 0)
	{
		return x-y;
	}
	if(strcmp(op, "mul") == 0)
	{
		return x*y;
	}
	if(strcmp(op, "div") == 0)
	{
		if(y == 0)
			return 0;
		else
			return x/y;
	}
}

// Function designed for chat between client and server. 
void func(int sockfd) 
{ 
		//declare variables
    char op[3]; 
    int x,y; 
    int success, result;
    // infinite loop for chat 
    for (;;) {  
        // read the message from client and copy it in buffer 
        recv(sockfd, &op, sizeof(op), 0);
        recv(sockfd, &x, sizeof(x), 0);
        recv(sockfd, &y, sizeof(y), 0); 
        // print buffer which contains the client contents 
        printf("From client: %s\n", op);
        printf("Value 1: %d\n", x);
        printf("Value 2: %d\n", y);
        
        //check inputs
				success = checkValid(op,x,y);
				result = calculate(op,x,y);
        // and send that buffer to client 
        send(sockfd, &success, sizeof(success), 0); 
        send(sockfd, &result, sizeof(result), 0);
    } 
} 
  
// Driver function 
int main() 
{ 
    int sockfd, connfd, len; 
    struct sockaddr_in servaddr, cli; 
  
    // socket create and verification 
    sockfd = socket(AF_INET, SOCK_STREAM, 0); 
    if (sockfd == -1) { 
        printf("socket creation failed...\n"); 
        exit(0); 
    } 
    else
        printf("Socket successfully created..\n"); 
    bzero(&servaddr, sizeof(servaddr)); 
  
    // assign IP, PORT 
    servaddr.sin_family = AF_INET; 
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY); 
    servaddr.sin_port = htons(PORT); 
  
    // Binding newly created socket to given IP and verification 
    if ((bind(sockfd, (SA*)&servaddr, sizeof(servaddr))) != 0) { 
        printf("socket bind failed...\n"); 
        exit(0); 
    } 
    else
        printf("Socket successfully binded..\n"); 
  
    // Now server is ready to listen and verification 
    if ((listen(sockfd, 5)) != 0) { 
        printf("Listen failed...\n"); 
        exit(0); 
    } 
    else
        printf("Server listening..\n"); 
    len = sizeof(cli); 
  
    // Accept the data packet from client and verification 
    connfd = accept(sockfd, (SA*)&cli, &len); 
    if (connfd < 0) { 
        printf("server acccept failed...\n"); 
        exit(0); 
    } 
    else
        printf("server acccept the client...\n"); 
  
    // Function for chatting between client and server 
    func(connfd); 
  
    // After chatting close the socket 
    close(sockfd); 
} 
