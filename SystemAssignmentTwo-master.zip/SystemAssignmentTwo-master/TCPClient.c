#include <netdb.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <sys/socket.h> 
#define MAX 80 
#define PORT 8082
#define SA struct sockaddr

// Function designed for chat between client and server.  
void func(int sockfd) 
{ 
		//declare variables
    char op[3]; 
    int x,y; 
    int success, result;
    for (;;) { 
    		//setup
        printf("Use add, sub, mul, div to specify operation, press control + c to exit\n");
        printf("Example: add 3 7\n");
        printf("Enter Value: \n"); 
        
        //read variables
        scanf("%s %d %d", &op, &x, &y);
        
        //send variables to server
        send(sockfd, &op, sizeof(op), 0);
        send(sockfd, &x, sizeof(x), 0);
        send(sockfd, &y, sizeof(y), 0); 
        
        //recieve results
        recv(sockfd, &success, sizeof(success), 0);
        recv(sockfd, &result, sizeof(result), 0);
        
        //print results
        if(success == 1)
        {
        	printf("Operation successful! Code: %d\n", success);
        }
        else
        {
        	printf("Operation unsuccessful. Code: %d\n", success);
        }
        printf("Result from server: %d\n", result); 
    } 
} 

//create server connection
int main() 
{ 
    int sockfd; 
    struct sockaddr_in servaddr; 
  
    // socket create and varification 
    sockfd = socket(AF_INET, SOCK_STREAM, 0); 
    if (sockfd == -1) { 
        printf("socket creation failed...\n"); 
        exit(0); 
    } 
    else
        printf("Socket successfully created..\n"); 
    bzero(&servaddr, sizeof(servaddr)); 
  
    // assign IP, PORT 
    servaddr.sin_family = AF_INET; 
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1"); 
    servaddr.sin_port = htons(PORT); 
  
    // connect the client socket to server socket 
    if (connect(sockfd, (SA*)&servaddr, sizeof(servaddr)) != 0) { 
        printf("connection with the server failed...\n"); 
        exit(0); 
    } 
    else
        printf("connected to the server..\n"); 
  
    // function for chat 
    func(sockfd); 
  
    // close the socket 
    close(sockfd); 
} 
