#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>

//function call for duplicate
void duplicate(char oldFile[], char newFile[])
{
	int fd1, fd2; //File descriptors for I/O
	char copy[100];//Line reader
	ssize_t readSize, writeSize, readTotal=0, writeTotal=0;//define size of reads and writes
	clock_t start; //Timer

	//try to open the original file
	if((fd1 = open(oldFile, O_RDONLY))<0)
	{
		printf("Error opening file: %s\n", oldFile);
		perror("Error");
		exit(1);
	}

	//try to open or create copy file
	if((fd2 = open(newFile, O_CREAT | O_WRONLY, 0777))<0)
	{
		printf("Error creating/opening file: %s\n", newFile);
		perror("Error");
		exit(1);
	}

	start = clock(); //Time file transfer
	int count = 1; //Count seconds

	//read the lines from the original file
	while((readSize = read(fd1, copy, 100))>0)
	{
		//Total read size
		readTotal += readSize;

		//Writing
		writeSize = write(fd2, copy, readSize);

		//Catch write error
		if(writeSize < 0)
		{
			printf("Duplicate: Could not write to file: %s\n", newFile);
			perror("Error");
			exit(1);
		}

		//Total write size
		writeTotal += writeSize;

		//Count Seconds and print every second
		if((clock()- start)/CLOCKS_PER_SEC >= count)
		{
			printf("duplicate: still duplicating...\n");
			count++;
		}
	}

	//Read error catch
	if(readSize < 0)
	{
		perror("Error");
		exit(1);
	}

	//Print size of read and write
	printf("Bytes read: %ld\n", readTotal);
	printf("Bytes written: %ld\n", writeTotal);

	//if size is the same, write successful
	if(readTotal == writeTotal)
	{
		printf("duplicate: Successfully copied %ld bytes from file %s to %s.\n", writeTotal, oldFile, newFile);
	}
	else
	{
		perror("Error in copying contents.");
		exit(1);
	}
	
	//close files
	close(fd1);
	close(fd2);

}


//main function
int main (int argc, char *argv[]){
	if(argc !=3){
		perror("Error");
		printf("duplicate: Incorrect number of arguments.\nUsage: duplicate <sourceFile> <targetFile>\n");
		exit(1);
		}
	
	duplicate(argv[1], argv[2]);
	
	return 0;
}
