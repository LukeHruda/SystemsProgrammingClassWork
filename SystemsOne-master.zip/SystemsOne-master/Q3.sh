#!/bin/bash
#Created by Luke Hruda - 100654666

#Initial Variable Declared
total=0
valid=false

#Ask student for name
echo "Please enter your name, no spaces"
read name

#Create File with student name and Time
echo "Creating file: $name.txt"
echo "Student name: $name" > $name.txt
currentTime=$(date)
echo "The start time is: $currentTime" >> $name.txt

#Remind the User to only seclect A or B as an option (case is ignored)
echo "This is a multiple choice Test, please only enter A or B"

#Ask user first question
echo "Q1. What is 9+10?"
echo "A. 19	B. 21"

#read single charatcter input
read -N 1 input

#Check if input is valid (A or B, case ignored)
case $input in
	a|A) valid=true ;;
	b|B) valid=true ;;
esac

#if the user did not enter a valid character, prompt them until the input is valid
while [ "$valid" != "true" ]
do
	printf "\n"
	echo "Invalid character, please try again."
	read -N 1 input
	case $input in
		a|A) valid=true ;;
		b|B) valid=true ;;
	esac

done
printf "\n"

#Write Question to file
echo "Q1. What is 9+10?" >> $name.txt

#Write Results to file
case $input in
	a|A) total=$((total + 1)) 
             echo "Answer: A - Correct!" >> $name.txt ;;
	b|B) echo "Answer: B - Incorrect" >> $name.txt ;;
esac

#Reset input check before next Question
valid=false

#Ask Question Two
echo "Q2. Which of these books did Shakespeare write?"
echo "A. The wheels on the bus    B. Hamlet"

#read single charatcter input
read -N 1 input

#Check if input is valid (A or B, case ignored)
case $input in
	a|A) valid=true ;;
	b|B) valid=true ;;
esac

#if the user did not enter a valid character, prompt them until the input is valid
while [ "$valid" != "true" ]
do
	printf "\n"
	echo "Invalid character, please try again."
	read -N 1 input
	case $input in
		a|A) valid=true ;;
		b|B) valid=true ;;
	esac

done
printf "\n"

#Write Question to file
echo "Q2. Which of these books did Shakespeare write?" >> $name.txt

#Write Results to file
case $input in
	a|A) echo "Answer: A - Incorrect" >> $name.txt ;;
	b|B) total=$((total + 1)) 
	     echo "Answer: B - Correct!" >> $name.txt ;;
esac

#Reset input check before next Question
valid=false

#Ask third Question
echo "Q3. 'BLT' stands for: "
echo "A. Bacon Lettuce Tomato	B. Brian Likes Toast"

#read single charatcter input
read -N 1 input

#Check if input is valid (A or B, case ignored)
case $input in
	a|A) valid=true ;;
	b|B) valid=true ;;
esac

#if the user did not enter a valid character, prompt them until the input is valid
while [ "$valid" != "true" ]
do
	printf "\n"
	echo "Invalid character, please try again."
	read -N 1 input
	case $input in
		a|A) valid=true ;;
		b|B) valid=true ;;
	esac

done
printf "\n"

#Write Question to file
echo "Q3. 'BLT' stands for: " >> $name.txt

#Write Results to file
case $input in
	a|A) total=$((total + 1)) 
	     echo "Answer: A - Correct!" >> $name.txt ;;
	b|B) echo "Answer: B - Incorrect" >> $name.txt ;;
esac

#Reset input check before next Question
valid=false

#Ask user the fourth question
echo "Q4. How many strings does a Guitar have"
echo "A. 4	B. 6"

#read single charatcter input
read -N 1 input

#Check if input is valid (A or B, case ignored)
case $input in
	a|A) valid=true ;;
	b|B) valid=true ;;
esac

#if the user did not enter a valid character, prompt them until the input is valid
while [ "$valid" != "true" ]
do
	printf "\n"
	echo "Invalid character, please try again."
	read -N 1 input
	case $input in
		a|A) valid=true ;;
		b|B) valid=true ;;
	esac

done
printf "\n"

#Write Question to file
echo "Q4. How many strings does a Guitar have" >> $name.txt

#Write Results to file
case $input in
	a|A) echo "Answer: A - Incorrect" >> $name.txt ;;
	b|B) total=$((total + 1)) 
	     echo "Answer: B - Correct!" >> $name.txt ;;
esac

#Reset input check before next Question
valid=false

#Ask the fifth question
echo "Q5. What is the answer to life the universe and everything?"
echo "A. Pasta	B. 42"

#read single charatcter input
read -N 1 input

#Check if input is valid (A or B, case ignored)
case $input in
	a|A) valid=true ;;
	b|B) valid=true ;;
esac

#if the user did not enter a valid character, prompt them until the input is valid
while [ "$valid" != "true" ]
do
	printf "\n"
	echo "Invalid character, please try again."
	read -N 1 input
	case $input in
		a|A) valid=true ;;
		b|B) valid=true ;;
	esac

done
printf "\n"

#Write Question to file
echo "Q5. What is the answer to life the universe and everything?" >> $name.txt

#Write Results to file
case $input in
	a|A) echo "Answer: A - Incorrect" >> $name.txt ;;
	b|B) total=$((total + 1)) 
	     echo "Answer: B - Correct!" >> $name.txt ;;
esac

#Print end time and results
echo "The test is finished, thank you $name."
currentTime=$(date)
echo "The start time is: $currentTime" >> $name.txt
echo "Final score: $total/5" >> $name.txt

