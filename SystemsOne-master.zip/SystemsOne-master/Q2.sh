#!/bin/bash
#Created by Luke Hruda - 100654666

#Tell the User how to stop the program.
echo "Press Control + C to exit"
echo "Created sampling.txt" > sampling.txt

#Infite while loop, with termination break condition.
while true; do

    #check current runtime of program in seconds
    time=$SECONDS

    #if the program's run time is greater than 5 seconds
    if [ $time -gt 5 ]; then

        #print the current time into sampling.txt
        echo $(date +"%T") >> sampling.txt

    fi
done
