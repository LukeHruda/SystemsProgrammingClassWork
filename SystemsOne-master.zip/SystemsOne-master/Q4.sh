#!/bin/bash
#Created by Luke Hruda - 100654666

#Print the number of lines for "A Tale of Two Cities"
echo "Number of lines in ATaleOfTwoCities.txt: "
#wc - l counts the number of lines in the file
lines=$ wc -l ATaleOfTwoCities.txt
echo $lines

#Print the number of lines for "Alice In Wonderland"
echo "Number of lines in AliceInWonderland.txt: "
#wc - l counts the number of lines in the file
lines=$ wc -l AliceInWonderland.txt
printf "\n"

echo "London and Paris count for ATaleOfTwoCities.txt:"
#Find and print the number of times London appears
echo "London count:"
london=$ grep -o London ATaleOfTwoCities.txt | wc -l


#Find and print the number of times Paris appears
echo "Paris count:"
paris=$ grep -o Paris ATaleOfTwoCities.txt | wc -l

#Line spacing
printf "\n"

#Print the number of vowels in "A Tale of Two Cities"
echo "Number of vowels in ATaleOfTwoCities.txt: "
vowels=$ grep -o -i [aeiouAEIOU] ATaleOfTwoCities.txt | wc -l

#Print the number of vowels in "Alice In Wonderland"
echo "Number of vowels in AliceInWonderland.txt: "
vowels=$ grep -o -i [aeiouAEIOU] AliceInWonderland.txt | wc -l

#Line spacing
printf "\n"

#Print the number of times "the" appears in "A Tale of Two Cities"
echo "'The' count for ATaleOfTwoCities.txt: "
the=$ grep -o -i the ATaleOfTwoCities.txt | wc -l

#Print the number of times "the" appears in "Alice In Wonderland"
echo "'The' count for AliceInWonderland.txt: "
the=$ grep -o -i the AliceInWonderland.txt | wc -l

#Line spacing
printf "\n"

#Replace 'the' with 'ABC' and print the copy to new file
echo "Replacing 'the' with ABC for ATaleOfTwoCities.txt"
replace=$ sed 's/the/ABC/g' ATaleOfTwoCities.txt > ABCATaleOfTwoCities.txt

#Replace 'the' with 'ABC' and print the copy to new file
echo "Replacing 'the' with ABC for AliceInWonderland.txt"
replace=$ sed 's/the/ABC/g' AliceInWonderland.txt > ABCAliceInWonderland.txt

#Line spacing
printf "\n"

#Count and print the number of unique characters for "A Tale of Two Cities"
echo "Unique character count in ATaleOfTwoCities.txt:"
unique=$ sed 's/\(.\)/\1\n/g' ATaleOfTwoCities.txt | sort | uniq -c

#Line spacing
printf "\n"

#Count and print the number of unique characters for "Alice In Wonderland"
echo "Unique character count in AliceInWonderland.txt:"
unique=$ sed 's/\(.\)/\1\n/g' AliceInWonderland.txt | sort | uniq -c



