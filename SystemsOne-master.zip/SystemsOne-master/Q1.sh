#!/bin/bash
#Created by Luke Hruda - 100654666

#Read the main string to be searched
echo "Please enter the main string:"
read mainString

#Read the sub string that is to be searched for
echo "Please enter the sub-string:"
read subString

#Set s equal to the main string, with all instances
#of the substring removed
s=${mainString//"$subString"}

#Equation for number of occurences is as follows:
#Length of main string minus length of s
#divided by the length of the substring
echo "Number of Occurences: ""$(((${#mainString} - ${#s}) / ${#subString}))"