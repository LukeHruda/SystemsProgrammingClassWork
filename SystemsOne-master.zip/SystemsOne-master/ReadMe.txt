Created by Luke Hruda - 100654666

Please note that all the scripts given in this file are bash scripts. 
They can be run from the terminal given you are calling them in the correct directory.
Example:
	cd bin
	./Q1.sh
Given that the scripts are located in the bin directory. Please call all of the scripts as:
./Q1.sh ./Q2.sh ./Q3.sh ./Q4.sh

*Note: All scripts are also thuroughly commented for a line by line explaination"

For Q1.sh:
The script asks the user to input the mainstring and the substring, then will automatically output the number of occurences into the terminal.
It does this by removing all of the occurences of the substring from the mainstring.
Then subtracting the length of the mainstring with the substring removed, from the length of the origional mainstring.
Then dividing that result by the length of the substring.

For Q2.sh:
We tell the user that the only way to terminate the process is by pressing "Control + C" which is the interupt command for the Ubuntu terminal.
The script will automatically create the file "sampling.txt" in whatever directory the script is in.
After 5 seconds the script will start writing the current time in format HH:MM:SS or 19:55:04 to the file.
A while true loop is used to ensure the file's execution will happen as fast as possible.

For Q3.sh:
We create a .txt file with the students name, and we print the student's name and the time they start into the file.
After printing a question and both possible answers, we read a single chracter of input from the user.
A case statement is performed to check if the user entered 'A', 'B' or an invalid character.
The case statement also allows us to ingore the case of 'A' or 'a', 'B' or 'b'.
If the character entered is invalid, we ask for another input.
When the character is valid, we check the correctness of the answer and add one to the count if it is correct.
We write the question, and the selected answer to the file.
This process is repeated for all 5 questions.
When the test is complete, the results out of 5 are printed into the file along with the end time.

For Q4.sh:
Both ATaleOfTwoCities.txt and AliceInWonderland.txt must be in the same directory as the script.
$ wc -l is used to count the number of lines in both documents.
$ grep -o London is used to count London and Paris in ATaleOfTwoCities.txt, -o is used to find only matching words as technically "Paris" is found in the word "Parish".
$ grep -o -i [aeiouAEIOU] is used to count the amount of vowels, -i means to ignore the case.
$ grep -o -i the is used to count the number of times "the" appears in both texts, regardless of case.
$ sed 's/the/ABC/g' is used to replace all of "the" in the text file with "ABC", in talking with the Professor he said only lowercase "the" needed to be replaced/
s/ is used to signify a replacement, /g is used to replace all the matching literals not just the first. the/ABC is a regex in the format old/new.
This is printed into the new file ABCATaleOfTwoCities.txt which is created in the same directory as the script.
$ sed 's/\(.\)/\1\n/g' ATaleOfTwoCities.txt | sort | uniq -c is used to print and sort the count of all unique characters in the .txt file.
This is done by finding unique ascii values across all the lines of the document, sorted by the unique character.